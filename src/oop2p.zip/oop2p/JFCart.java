/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package oop2p;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.awt.PopupMenu;
import java.util.Vector;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.sql.SQLException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;



/**
 *
 * @author Deema Alfaleh
 */
public class JFCart extends javax.swing.JFrame {
   Connection con=main.CreateConnection();
    Statement st;
    ResultSet rs;
    static void setvisable(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
 DefaultTableModel table ;
    double totalPrice ;
   
    public JFCart() {
       // this.table = new DefaultTableModel();
        initComponents();
         showAllBooks();
        //table.setNumRows(1);
        }
    
    //  private void loadCart(){
    //      totalPrice = 0;
    //      table.setNumRows(0);
    //     table.insertRow(table.getRowCount(), cart.getbookInfo());
    // </editor-fold>

 //  private void loadCart(){
  //      totalPrice = 0;
  //      table.setNumRows(0);
   //     table.insertRow(table.getRowCount(), cart.getbookInfo());
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        p = new java.awt.Panel();
        combo = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        ADD = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        borrow_date = new javax.swing.JTextField();
        Return_date = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        Confirm_order = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel21 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        p.setBackground(new java.awt.Color(250, 250, 241));
        p.setLayout(new java.awt.GridLayout(4, 3, 2, 2));
        jPanel1.add(p, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 170, 440, 450));

        combo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All Books", "Study Books", "Other Books", " " }));
        combo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboActionPerformed(evt);
            }
        });
        jPanel1.add(combo, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 140, -1, -1));

        jLabel3.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        jLabel3.setText(" Category:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 140, -1, -1));

        jLabel12.setFont(new java.awt.Font("Serif", 1, 24)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(102, 0, 0));
        jLabel12.setText("BOOKS");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 70, -1, -1));

        jLabel13.setFont(new java.awt.Font("Serif", 0, 8)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(102, 102, 0));
        jLabel13.setText("THE WISE BOOK LIBRARY");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 50, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/oop2p/99.png"))); // NOI18N
        jScrollPane1.setViewportView(jLabel1);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 460, 300));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 670, 630));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 420, 620));

        jPanel3.setBackground(new java.awt.Color(234, 240, 240));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/oop2p/0000.png"))); // NOI18N
        jLabel2.setText("jLabel2");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, -10, -1, 130));

        jLabel16.setText("Enter The Book Id :");
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, -1, -1));
        jPanel3.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 110, 80, 20));

        ADD.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        ADD.setText("Add To Cart");
        ADD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ADDActionPerformed(evt);
            }
        });
        jPanel3.add(ADD, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 150, 120, -1));

        delete.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        delete.setText("Delete from cart");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        jPanel3.add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 180, 120, -1));

        jLabel17.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        jLabel17.setText("Total Price:");
        jPanel3.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 330, 130, -1));

        jLabel18.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        jLabel18.setText("Borrow?");
        jPanel3.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 370, -1, -1));

        borrow_date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrow_dateActionPerformed(evt);
            }
        });
        jPanel3.add(borrow_date, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 400, 120, -1));
        jPanel3.add(Return_date, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 430, 120, -1));

        jLabel19.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        jLabel19.setText("Borrow Date:");
        jPanel3.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 400, -1, -1));

        jLabel20.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        jLabel20.setText("Return Date:");
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 430, -1, -1));

        Confirm_order.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        Confirm_order.setText("Conform Order");
        Confirm_order.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Confirm_orderActionPerformed(evt);
            }
        });
        jPanel3.add(Confirm_order, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 470, -1, -1));

        jTable1.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Book name", "ID", "Price"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        jPanel3.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, 230, 100));

        jLabel21.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        jLabel21.setText("For Return a book ");
        jPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 530, -1, -1));

        jButton4.setFont(new java.awt.Font("Serif", 0, 12)); // NOI18N
        jButton4.setText("Return");
        jPanel3.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 530, -1, 20));

        jLabel22.setBorder(javax.swing.BorderFactory.createEtchedBorder(java.awt.Color.white, java.awt.Color.white));
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 210, 70));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 0, 260, 620));

        pack();
    }// </editor-fold>//GEN-END:initComponents
   
    private void borrow_dateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borrow_dateActionPerformed
    }//GEN-LAST:event_borrow_dateActionPerformed

    private void Confirm_orderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Confirm_orderActionPerformed
 
      //  bill_borrow = new Bill();
    //   bill_buy = new Bill();

        
    //    if(Return_date=="" && borrow_date=="" ){
       // bill_borrow.setVisible(true);
        //book.setVisible(false);}
       // else{ bill_buy.setVisible(true);
       // book.setVisible(false);}
    }//GEN-LAST:event_Confirm_orderActionPerformed
    
    private void ADDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ADDActionPerformed
      // loadCart();


    }//GEN-LAST:event_ADDActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
      if (jTable1.getSelectedRow() != -1) {
          
            table.removeRow(jTable1.getSelectedRow());
        }


    }//GEN-LAST:event_deleteActionPerformed

    private void comboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboActionPerformed
        
            //showAllBooks();
        
        // TODO add your handling code here:
    }//GEN-LAST:event_comboActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JFCart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JFCart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JFCart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFCart.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFCart().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ADD;
    private javax.swing.JButton Confirm_order;
    private javax.swing.JTextField Return_date;
    private javax.swing.JTextField borrow_date;
    private javax.swing.JComboBox<String> combo;
    private javax.swing.JButton delete;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jTextField1;
    private java.awt.Panel p;
    // End of variables declaration//GEN-END:variables
   public void showAllBooks(){
      try{
          p.removeAll();
          p.revalidate();
          p.repaint();
          p.setLayout(new java.awt.GridLayout(3,3,2,2));
                String query="select * from books";
            st=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            rs=st.executeQuery(query);
            int rows=0;
            rs.last();
            rows=rs.getRow();
            JLabel[]books=new JLabel[rows];
            rs.beforeFirst();
            while(rs.next()){
            for(int i=0;i<1;i++){
            books[i]=new JLabel(rs.getString("booktitle")+"("+rs.getString("price")+"$"+")",new javax.swing.ImageIcon(getClass().getResource(rs.getString("icon"))),SwingConstants.LEFT);
               books[i].setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
               books[i].setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
               books[i].setMinimumSize(new java.awt.Dimension(500, 120));
               books[i].setMaximumSize(new java.awt.Dimension(500, 120));
               books[i].setPreferredSize(new java.awt.Dimension(500, 120));
               books[i].setFont(new java.awt.Font("Verdana Pro Cond",0, 12));
               p.add(books[i]);
   
        }}}
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }  
    }
    private PopupMenu jScrollPane1(JLabel jLabel1) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

//    private void initComponents() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    }

    private Vector<?> getbookInfo() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
}
